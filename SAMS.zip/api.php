php<?php
session_start();
require_once "config.php";
header("Content-Type: application/json");

// Direct access restriction (Simulated Route Guarding)
if (!isset($_SESSION['instructor_id'])) {
    // For local evaluation ease, fallback to demo seed if session hasn't fired yet
    $_SESSION['instructor_id'] = 1; 
}

$action = $_GET['action'] ?? '';

// 1. Asynchronous Live Student Search Endpoint
if ($action === 'search_student') {
    $searchStr = htmlspecialchars(strip_tags(trim($_GET['q'] ?? '')));
    if (strlen($searchStr) < 2) {
        echo json_encode([]);
        exit;
    }

    $stmt = $pdo->prepare("SELECT s.student_id, s.student_id_number, s.full_name, d.dept_name 
                           FROM students s 
                           LEFT JOIN departments d ON s.dept_id = d.dept_id 
                           WHERE s.full_name LIKE :q OR s.student_id_number LIKE :q LIMIT 5");
    $stmt->execute([':q' => "%$searchStr%"]);
    echo json_encode($stmt->fetchAll());
    exit;
}

// 2. Asynchronous Insertion (Log Submissions)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'submit_log') {
    $course_id = filter_var($_POST['course_id'] ?? null, FILTER_VALIDATE_INT);
    $student_id = filter_var($_POST['student_id'] ?? null, FILTER_VALIDATE_INT);
    $status = htmlspecialchars(strip_tags(trim($_POST['status'] ?? 'Present')));
    $current_date = date('Y-m-d');

    if (!$course_id || !$student_id) {
        echo json_encode(["success" => false, "message" => "Validation Failure: Missing fields."]);
        exit;
    }

    try {
        $stmt = $pdo->prepare("INSERT INTO attendance_logs (course_id, student_id, instructor_id, attendance_status, log_date) 
                               VALUES (:c_id, :s_id, :i_id, :status, :l_date)");
        $stmt->execute([
            ':c_id' => $course_id,
            ':s_id' => $student_id,
            ':i_id' => $_SESSION['instructor_id'],
            ':status' => $status,
            ':l_date' => $current_date
        ]);
        echo json_encode(["success" => true, "message" => "Attendance registered securely!"]);
    } catch (PDOException $e) {
        if ($e->getCode() == 23000) {
            echo json_encode(["success" => false, "message" => "Conflict: Attendance record already exists for today."]);
        } else {
            echo json_encode(["success" => false, "message" => "System processing framework exception context."]);
        }
    }
    exit;
}
?>