javascriptdocument.addEventListener("DOMContentLoaded", () => {
    const searchInput = document.getElementById("liveSearchInput");
    const dropdownCollection = document.getElementById("dropdownCollection");
    const selectionBadge = document.getElementById("selectionBadge");
    const targetLabel = document.getElementById("targetLabel");
    const hiddenStudentField = document.getElementById("hiddenStudentField");
    const attendanceForm = document.getElementById("attendanceSubmissionForm");
    const msgNotification = document.getElementById("submissionResponse");

    // Asynchronous Fetch Engine Input Mapping
    searchInput.addEventListener("input", async () => {
        const value = searchInput.value.trim();
        
        if (value.length < 2) {
            dropdownCollection.innerHTML = "";
            dropdownCollection.classList.add("hidden");
            return;
        }

        try {
            const res = await fetch(`api.php?action=search_student&q=${encodeURIComponent(value)}`);
            const data = await res.json();

            dropdownCollection.innerHTML = "";
            if (data.length === 0) {
                dropdownCollection.innerHTML = `<div class="dropdown-row">No records match lookup criteria</div>`;
                dropdownCollection.classList.remove("hidden");
                return;
            }

            data.forEach(student => {
                const element = document.createElement("div");
                element.className = "dropdown-row";
                element.textContent = `${student.full_name} (${student.student_id_number}) - ${student.dept_name}`;
                
                element.addEventListener("click", () => {
                    targetLabel.textContent = `${student.full_name} [${student.student_id_number}]`;
                    hiddenStudentField.value = student.student_id;
                    selectionBadge.classList.remove("hidden");
                    dropdownCollection.classList.add("hidden");
                    searchInput.value = "";
                });
                dropdownCollection.appendChild(element);
            });
            dropdownCollection.classList.remove("hidden");
        } catch (err) {
            console.error("Asynchronous pipeline processing interruption error.");
        }
    });

    // Form Event Handler Execution Routing
    attendanceForm.addEventListener("submit", async (e) => {
        e.preventDefault();
        msgNotification.textContent = "";

        const courseId = document.getElementById("courseSelect").value;
        const studentId = hiddenStudentField.value;
        const status = document.getElementById("statusSelect").value;

        // Front-End Verification Step
        if (!studentId) {
            msgNotification.style.color = "#ef4444";
            msgNotification.textContent = "Error: You must pick a verified student via search selection lookup.";
            return;
        }

        const formData = new FormData();
        formData.append("course_id", courseId);
        formData.append("student_id", studentId);
        formData.append("status", status);

        try {
            const response = await fetch("api.php?action=submit_log", { method: "POST", body: formData });
            const result = await response.json();

            if (result.success) {
                msgNotification.style.color = "#22c55e";
                msgNotification.textContent = result.message;
                selectionBadge.classList.add("hidden");
                hiddenStudentField.value = "";
            } else {
                msgNotification.style.color = "#ef4444";
                msgNotification.textContent = result.message;
            }
        } catch (error) {
            msgNotification.style.color = "#ef4444";
            msgNotification.textContent = "System Error: Submission pathway breakdown.";
        }
    });

    document.addEventListener("click", (e) => {
        if (!searchInput.contains(e.target) && !dropdownCollection.contains(e.target)) {
            dropdownCollection.classList.add("hidden");
        }
    });
});