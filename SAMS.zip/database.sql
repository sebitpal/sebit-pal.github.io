sqlCREATE DATABASE IF NOT EXISTS smart_attendance_db;
USE smart_attendance_db;

-- 1. Departments Table
CREATE TABLE IF NOT EXISTS departments (
    dept_id INT AUTO_INCREMENT PRIMARY KEY,
    dept_name VARCHAR(100) UNIQUE NOT NULL,
    building_block VARCHAR(50) NOT NULL
) ENGINE=InnoDB;

-- 2. Courses Table (One-to-Many with Departments)
CREATE TABLE IF NOT EXISTS courses (
    course_id INT AUTO_INCREMENT PRIMARY KEY,
    course_code VARCHAR(15) UNIQUE NOT NULL,
    course_name VARCHAR(100) NOT NULL,
    dept_id INT,
    FOREIGN KEY (dept_id) REFERENCES departments(dept_id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- 3. Users/Instructors Table (With Password Hashing)
CREATE TABLE IF NOT EXISTS instructors (
    instructor_id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 4. Students Table (One-to-Many with Departments)
CREATE TABLE IF NOT EXISTS students (
    student_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id_number VARCHAR(25) UNIQUE NOT NULL, -- e.g., EGR/4122/16
    full_name VARCHAR(100) NOT NULL,
    dept_id INT,
    FOREIGN KEY (dept_id) REFERENCES departments(dept_id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- 5. Attendance Logs Table (Many-to-Many Junction / Records Logs)
CREATE TABLE IF NOT EXISTS attendance_logs (
    log_id INT AUTO_INCREMENT PRIMARY KEY,
    course_id INT NOT NULL,
    student_id INT NOT NULL,
    instructor_id INT NOT NULL,
    attendance_status ENUM('Present', 'Absent', 'Late') DEFAULT 'Present',
    log_date DATE NOT NULL,
    check_in_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (course_id) REFERENCES courses(course_id) ON DELETE CASCADE,
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
    FOREIGN KEY (instructor_id) REFERENCES instructors(instructor_id) ON DELETE CASCADE,
    UNIQUE KEY unique_session_entry (course_id, student_id, log_date)
) ENGINE=InnoDB;

-- --- SEED DATA FOR DEMO EXTRACTION ---
INSERT INTO departments (dept_name, building_block) VALUES 
('Software Engineering', 'BiT Block 4 (ICT Lab)'),
('Electrical Engineering', 'BiT Block 2');

INSERT INTO courses (course_code, course_name, dept_id) VALUES 
('SEng-3111', 'Web Development Frameworks', 1),
('ECEg-4212', 'Control Systems', 2);

-- Default Demo Password is 'Abit1234!' hashed via PASSWORD_DEFAULT
INSERT INTO instructors (full_name, email, password_hash) VALUES 
('Dr. Dawit Yoseph', 'dawit.yoseph@bit.edu.et', '$2y$10$7R64EolrXf7RfeAghgC9SuWv4v9F8wRmWUunvpxv8wY9fCKeVw2wW');

INSERT INTO students (student_id_number, full_name, dept_id) VALUES 
('EGR/0014/16', 'Biniam Yoseph', 1),
('EGR/0842/16', 'Selamawit Tadesse', 1),
('EGR/1290/16', 'Tariku Lemma', 2);